package GlobalConstants;

public class MarketState {
	public static final String OPEN = "OPEN";
	public static final String CLOSED = "CLOSED";
	public static final String PREOPEN = "PREOPEN";
}

package tradable;

public class BookSide {
	public static final String BUY = "BUY";
	public static final String SELL = "SELL";
}

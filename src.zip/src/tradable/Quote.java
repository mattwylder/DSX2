package tradable;

import price.Price;

public class Quote {
	
	String user;
	String stockSymbol;
	QuoteSide buy;
	QuoteSide sell;
	
	
	public Quote(String userName, String productSymbol,
			Price buyPrice, int buyVolume,
			Price sellPrice, int sellVolume) throws Exception{
		if(buyVolume < 1){
			throw new Exception("Cannot have 0 or negative buy volume");
		}
		user = userName;
		stockSymbol = productSymbol;
	}
	
	public String getUserName(){
		return user;
	}
	
	public String getProdcut(){
		return stockSymbol;
	}
	
	public QuoteSide getQuoteSide(String sideln){
		
		return null;
	}
	
	public String toString(){
		return null;
	}
}
package tradable;

import price.Price;

public class QuoteSide implements Tradable {

	String user;
	String stockSymbol;
	String id;
	Price sideP;
	int volume;
	long time = System.nanoTime();
	String side;
	String userName;
	String product;
	Price price;
	int originalVolume;
	int remainingVolume;
	int cancelledVolume;
	boolean quote;

	public QuoteSide(String userName, String productSymbol, Price sidePrice,
			int originalVolume, String sideB) throws Exception {
		if(originalVolume < 1){
			throw new Exception("Cannot have 0 or negative buy volume");
		}
		user = userName;
		stockSymbol = productSymbol;
		sideP = sidePrice;
		volume = originalVolume;
		side = sideB;

		id = userName + stockSymbol + time;

	}

	public QuoteSide(QuoteSide qs) {
		user = qs.getUserName();
		stockSymbol = qs.getProduct();
		volume = qs.getVolume();
		side = qs.getSide();
	}

	public String getUserName() {
		return user;
	}

	public String getProdcut() {
		return stockSymbol;
	}

	public QuoteSide getQuoteSide(String sideln) {

		return null;
	}

	public int getVolume() {
		return volume;
	}

	public String getProduct() {
		return product;
	}

	public Price getPrice() {
		return price;
	}

	public int getOriginalVolume() {
		return originalVolume;
	}

	public int getRemainingVolume() {
		return remainingVolume;
	}

	public int getCancelledVolume() {
		return cancelledVolume;
	}

	public void setRemainingVolume(int newRemainingVolume) throws Exception{
		if(newRemainingVolume > originalVolume){
			throw new Exception("Cannot cancel more volume than original volume");
		}
		remainingVolume = newRemainingVolume;
	}
	
	public void setCancelledVolume(int newCancelledVolume) throws Exception {
		if(newCancelledVolume > originalVolume){
			throw new Exception("Cannot cancel more volume than original volume");
		}
		cancelledVolume = newCancelledVolume;
	}

	public String getUser() {
		return userName;
	}

	public String getSide() {
		return side;
	}

	public boolean isQuote() {
		return false;
	}

	public String getId() {
		return user + stockSymbol + time;
	}
	
	public String toString(){
		return null;
	}

}
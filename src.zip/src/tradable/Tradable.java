package tradable;

import price.Price;

public interface Tradable {

		String getProduct();
		 
		Price getPrice();
		
		int getOriginalVolume();
		
		int getRemainingVolume();
		
		int getCancelledVolume();
		
		void setRemainingVolume(int newRemainingVolume) throws Exception;
		
		void setCancelledVolume(int newCancelledVolume) throws Exception;
		
		String getUser();
		
		String getSide();
		
		boolean isQuote();
		
		String getId();
				
}
package publisher;

public class NotSubscribedException extends Exception {

	public NotSubscribedException(String msg){
		super(msg);
	}
}

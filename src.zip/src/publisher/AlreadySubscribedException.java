package publisher;

public class AlreadySubscribedException extends Exception{
	
	public AlreadySubscribedException(String msg){
		super(msg);
	}

}

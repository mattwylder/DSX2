package message;

public class InvalidDataOperation extends Exception {

		private static final long serialVersionUID = 1L;

		public InvalidDataOperation(String message) {
			super(message);
		}
	}


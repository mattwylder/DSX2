package price;


import java.util.HashMap;
import java.util.Map;
import java.util.regex.*;


public class PriceFactory {
	
	private static Map<String,Price> prices = new HashMap<String, Price>();
	private static Price market = new MarketPrice();
	
	public static Price makeLimitPrice(String value){
		
		//System.("Hey");
		
		value = value.replaceAll("[$]", "");
		//System.out.println("Value = " + value);
		
		if(prices.containsKey(value)){
//			System.out.println("getting old");
			return prices.get(value);
		}
		else{
//			System.out.println("Making new");
			Price p = new Price((long) (Double.parseDouble(value) * 100));
			prices.put(value, p);
			return p;
		}
	}
	public static Price makeLimitPrice(long value){
		
		String val = String.format("%d.%d", value/100, Math.abs(value % 100));
		return makeLimitPrice(val);
		
	}
	
	public static Price makeMarketPrice(){
		return market;
	}
		
}

package price;

public class InvalidPriceOperation extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPriceOperation(String message) {
		super(message);
	}
}
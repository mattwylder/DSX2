package price;

public class Price {
	
	private long value; //value in cents


	//CONSTRUCTORS
	protected Price(){
		this.value = 0; //TODO: idk
	}
	protected Price(long value){
		this.value = value;
	}

	protected long getValue(){
		return value;
	}
	
	// PRICE MATH
	public Price add(Price p) throws  Exception{
		if(isMarket()){
			throw new Exception("Cannot multiply Market Price");
		}
		return PriceFactory.makeLimitPrice(value + p.getValue());
	}
	
	public Price subtract(Price p) throws  Exception{
		if(isMarket()){
			throw new Exception("Cannot multiply Market Price");
		}
		return PriceFactory.makeLimitPrice(value - p.getValue());
	}
	
	public Price multiply(int p) throws Exception{
		if(isMarket()){
			throw new Exception("Cannot multiply Market Price");
		}
		return PriceFactory.makeLimitPrice(value * p);
	}
	
	
	
	// 	PRICE COMPARISONS
	//TODO: Throw InvalidPriceOperation if either are Market or null
	public boolean greaterOrEqual(Price p)throws InvalidPriceOperation{
		
		return value >= p.getValue();
	}
	public boolean greaterThan(Price p)throws InvalidPriceOperation{
	
		return value > p.getValue();
	}

	public boolean lessOrEqual(Price p)throws InvalidPriceOperation{
		
		return value <= p.getValue();
	}	
	
	public boolean lessThan(Price p)throws InvalidPriceOperation{
		
		return value <= p.getValue();
	}
	
	public boolean equals(Price p)throws InvalidPriceOperation{
		return value == p.getValue();
	}
	
	public boolean isMarket(){
		return false;
	}
	
	public boolean isNegative(){
		return value < 0;
	}
	
	public String toString(){
		long dollars = value / 100;
		long cents = value % 100;
		String message = "";
		if((dollars < 0) || (cents < 0))
		{
			message = String.format("$-%,d",Math.abs(dollars)) + String.format(".%02d",Math.abs(cents));
		}
		else
		{message = String.format("$%,d",dollars) + String.format(".%02d",cents);}
		return message;	}
}

package driver;

import price.PriceFactory;

public class MattTest {
	public static void main(String[] args){
		System.out.println(PriceFactory.makeLimitPrice(1043));
		System.out.println(PriceFactory.makeLimitPrice("$10.43"));
	}
}
